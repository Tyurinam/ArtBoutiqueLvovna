<!--
	* 
    * Projet : Travail pratique#1
               lancer des enchères et  participer à ces enchères.
	* Organisation : Collège de Maisonneuve
    * @author Jesus MARTINEZ REYNOSO, Marina Tyurina
    * @version 2017-02-15
-->

<!--

			* Projet : Travail pratique#1
               		 lancer des enchères et  participer à ces enchères.
			* Organisation : Collège de Maisonneuve
			* @author Jesus MARTINEZ REYNOSO, Marina Tyurina
			* @version 2017-02-15
			* Description : préparer les variables globales
              description en anglais
			  pour tous les fichiers le Côté administrateur
			  comme outille  de OpenCart
-->

<?php
// Heading
$_['heading_title']    = 'Auctions Client';


// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Enchercles module!';
$_['text_edit']        = 'Edit Enchercles Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Enchercles module!';



