<?php
// Heading
$_['heading_title']    = 'Selection Oeuvres';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Selection Oeuvres module!';
$_['text_edit']        = 'Edit Selection Oeuvres Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Selection Oeuvres module!';