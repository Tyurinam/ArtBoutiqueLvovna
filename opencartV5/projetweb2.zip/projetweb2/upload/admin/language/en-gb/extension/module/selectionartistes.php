<?php
// Heading
$_['heading_title']    = 'Selection Artistes';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Selection Artistes module!';
$_['text_edit']        = 'Edit Selection Artistes Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Selection Artistes module!';