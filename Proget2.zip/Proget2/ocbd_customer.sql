-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2+deb7u8
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Mar 21 Mars 2017 à 20:49
-- Version du serveur: 5.5.54
-- Version de PHP: 5.4.45-0+deb7u7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `e1596124`
--

-- --------------------------------------------------------

--
-- Structure de la table `ocbd_customer`
--

CREATE TABLE IF NOT EXISTS `ocbd_customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_group_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(96) NOT NULL,
  `telephone` varchar(32) NOT NULL,
  `fax` varchar(32) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(9) NOT NULL,
  `cart` text,
  `wishlist` text,
  `newsletter` tinyint(1) NOT NULL DEFAULT '0',
  `address_id` int(11) NOT NULL DEFAULT '0',
  `custom_field` text NOT NULL,
  `ip` varchar(40) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `approved` tinyint(1) NOT NULL,
  `safe` tinyint(1) NOT NULL,
  `token` text NOT NULL,
  `code` varchar(40) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Contenu de la table `ocbd_customer`
--

INSERT INTO `ocbd_customer` (`customer_id`, `customer_group_id`, `store_id`, `language_id`, `firstname`, `lastname`, `email`, `telephone`, `fax`, `password`, `salt`, `cart`, `wishlist`, `newsletter`, `address_id`, `custom_field`, `ip`, `status`, `approved`, `safe`, `token`, `code`, `date_added`) VALUES
(1, 1, 0, 2, 'a', 'a', 'aaa@aaa.ca', '12345', '', '1c0c66d00b9427e443a3ef229b988cd0512ada4b', '1mtctdWgO', NULL, NULL, 0, 1, '', '10.30.232.15', 1, 1, 0, '', '', '2017-02-03 17:19:30'),
(2, 1, 0, 2, 'bb', 'bbbbb', 'bbbb@bbb.ca', '562577', '', '37d387dd0aca709d4282203b95470c683171794b', '4YLcLFdFx', NULL, NULL, 0, 2, '', '10.30.232.15', 1, 1, 0, '', '', '2017-02-03 17:25:42'),
(3, 1, 0, 2, 'ccc', 'cccc', 'ccc@ccc.ccc', '5647', '', '036b85ee02d721d63124660058064f9c1b1c6f12', '1eMst01z4', NULL, NULL, 0, 3, '', '10.30.232.15', 1, 1, 0, '', '', '2017-02-03 17:37:35'),
(4, 1, 0, 2, 'hkhkhhk', 'jjkljkj', 'hjh@gg.ca', '4654153', '', 'b0133455340139ebc446cfb0e661708808a09ec2', 'WroTW8LX3', NULL, NULL, 0, 4, '', '10.30.232.23', 1, 1, 0, '', '', '2017-02-06 16:19:41'),
(5, 1, 0, 2, 'fdzghfh', 'hdfh', 'fff@hh.ca', '13416+549+', '', '99798620bdeccdafa5b409d7d690d5d3eb037b1e', 'hunRoa8AU', NULL, NULL, 0, 5, '', '10.30.232.23', 1, 1, 0, '', '', '2017-02-06 16:31:49'),
(6, 1, 0, 2, 'ghg', 'gg', 'fg@ff.ca', '14524', '', 'a2989f40264a38ad0116568777f11cf6964c6780', 'e0HJkNxJa', NULL, NULL, 0, 6, '', '10.30.232.23', 1, 1, 0, '', '', '2017-02-06 16:38:53'),
(7, 1, 0, 2, 'ergjk;rogho;', 'betkl', 'fg@fff.ca', '1534gjmj', '', 'de618807285ad76c0c51d629b255e5f23b6e8d1b', 'ABdScGOrK', NULL, NULL, 0, 7, '', '10.30.232.23', 1, 1, 0, '', '', '2017-02-06 16:48:24'),
(8, 1, 0, 2, 'Jesus', 'Mart', 'jesus@gmail.com', '3465465464', '', 'f52245f6f2dea969873b849e417891e24bb7c785', '7Uu9rPwOa', NULL, NULL, 0, 8, '', '10.30.232.23', 1, 1, 0, '', '', '2017-02-06 17:00:08'),
(9, 1, 0, 2, 'dfbndg', 'dbnb', 'dd@vb.ru', '1213425643', '', '58db5ba54795a5e207d869d05c9aeb2b7a316d10', 'OB5Ey4blI', NULL, NULL, 0, 9, '', '10.30.232.23', 1, 1, 0, '', '', '2017-02-06 17:18:07'),
(10, 1, 0, 1, 'jwgpwr', 'ebnrklgh', 'ero@gh.ca', '12213', '', 'd726f55d89e8355b2ede5830a3cb47158bc08f2b', 'p3uIkIrPi', NULL, NULL, 0, 10, '', '10.30.232.23', 1, 1, 0, '', '', '2017-02-06 17:24:47'),
(11, 1, 0, 2, 'dkl;fh', 'dhfmfklh', 'fg@d.ca', '111', '', 'adfaf2faa7ad679576505c82f0fed9b90b1b5606', 'wekIp0bDW', NULL, NULL, 0, 11, '', '10.30.232.23', 1, 1, 0, '', '', '2017-02-07 17:00:19'),
(12, 1, 0, 2, 'asf', 'fafsd', 'aaa@aaa.ru', '123', '', '5ecbf4c8952dfd0df735bd2a529ccdabd249c64f', 'gIGY9KAvQ', NULL, NULL, 0, 12, '', '10.30.232.23', 1, 1, 0, '', '', '2017-02-08 16:02:13'),
(13, 1, 0, 2, 'Marina', 'MMM', 'mmm@ca.ca', '123123123', '', '504156fe876367578a5514eecbb2fc972e3e05df', 'jAhTRAsVX', NULL, NULL, 0, 13, '', '10.30.232.29', 1, 1, 0, '', '', '2017-02-13 20:08:38'),
(14, 1, 0, 1, 'Tom', 'Tom', 'tom@gmail.ca', '123456789', '', 'ccf573e7aada3e85a696b0daaa4acaf7f849dfa0', 'XGRMKQcGf', NULL, NULL, 0, 14, '', '198.48.195.61', 1, 1, 0, '', '', '2017-02-14 21:34:05'),
(15, 1, 0, 1, 'Jesus', 'Martinez', 'jjmartinez.reynoso@gmail.com', '5146012372', '', 'b9391cace314a2e7948e625a0a759f1ec332e065', 'TRCkUQRE2', NULL, NULL, 1, 15, '', '173.178.111.213', 1, 1, 0, '', '', '2017-02-14 23:03:49');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
