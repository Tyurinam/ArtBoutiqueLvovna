-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2+deb7u8
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Mer 22 Mars 2017 à 15:49
-- Version du serveur: 5.5.54
-- Version de PHP: 5.4.45-0+deb7u7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `e1596124`
--

-- --------------------------------------------------------

--
-- Structure de la table `ocbd_product`
--

CREATE TABLE IF NOT EXISTS `ocbd_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(64) NOT NULL,
  `sku` varchar(64) NOT NULL,
  `upc` varchar(12) NOT NULL,
  `ean` varchar(14) NOT NULL,
  `jan` varchar(13) NOT NULL,
  `isbn` varchar(17) NOT NULL,
  `mpn` varchar(64) NOT NULL,
  `location` varchar(128) NOT NULL,
  `quantity` int(4) NOT NULL DEFAULT '0',
  `stock_status_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `manufacturer_id` int(11) NOT NULL,
  `shipping` tinyint(1) NOT NULL DEFAULT '1',
  `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `points` int(8) NOT NULL DEFAULT '0',
  `tax_class_id` int(11) NOT NULL,
  `date_available` date NOT NULL DEFAULT '0000-00-00',
  `weight` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `weight_class_id` int(11) NOT NULL DEFAULT '0',
  `length` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `width` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `height` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `length_class_id` int(11) NOT NULL DEFAULT '0',
  `subtract` tinyint(1) NOT NULL DEFAULT '1',
  `minimum` int(11) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `viewed` int(5) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=60 ;

--
-- Contenu de la table `ocbd_product`
--

INSERT INTO `ocbd_product` (`product_id`, `model`, `sku`, `upc`, `ean`, `jan`, `isbn`, `mpn`, `location`, `quantity`, `stock_status_id`, `image`, `manufacturer_id`, `shipping`, `price`, `points`, `tax_class_id`, `date_available`, `weight`, `weight_class_id`, `length`, `width`, `height`, `length_class_id`, `subtract`, `minimum`, `sort_order`, `status`, `viewed`, `date_added`, `date_modified`) VALUES
(50, 'MULTI-SURFACE PREMIUM WAX BRUSH BY CRAFT SMART', '', '', '', '', '', '', '', 1, 7, 'catalog/11060_shin_ox.jpg', 13, 1, 20.0000, 0, 9, '2016-12-01', 0.00000000, 1, 0.00000000, 0.00000000, 0.00000000, 1, 1, 1, 200, 1, 7, '2016-12-07 17:17:55', '2016-12-14 17:34:13'),
(51, 'CANVAS 18'''' x 36''''', '', '', '', '', '', '', '', 1, 7, 'catalog/Toile.jpg', 11, 1, 30.0000, 0, 9, '2016-12-01', 0.20000000, 1, 18.00000000, 0.00000000, 36.00000000, 3, 1, 1, 1, 1, 24, '2016-12-07 18:08:51', '2016-12-15 00:36:00'),
(52, 'Toile d''artiste standard Apollon 9'''' x 12''''', '', '', '', '', '', '', '', 1, 7, 'catalog/Toile a peindre.jpg', 12, 1, 6.0000, 0, 9, '2016-12-10', 0.00000000, 1, 9.00000000, 0.00000000, 12.00000000, 3, 1, 1, 1, 1, 3, '2016-12-14 10:18:10', '2016-12-14 17:35:25'),
(53, 'Acrylique Golden Open 59ml', '', '', '', '', '', '', '', 1, 6, 'catalog/acrylique-golden-open-59ml.png', 14, 1, 8.7000, 0, 9, '2016-12-10', 0.00000000, 1, 0.00000000, 0.00000000, 0.00000000, 1, 1, 1, 1, 1, 15, '2016-12-14 10:41:48', '2016-12-14 17:21:35'),
(54, 'Boîte de 6 acryliques fluides Golden', '', '', '', '', '', '', '', 1, 7, 'catalog/Boitegolden-acrylique-principal.jpg', 14, 1, 47.0000, 0, 9, '2016-12-02', 0.00000000, 1, 0.00000000, 0.00000000, 0.00000000, 1, 1, 1, 1, 1, 6, '2016-12-14 13:24:29', '2017-01-27 16:20:24'),
(55, 'Grand chevalet M12', '', '', '', '', '', '', '', 1, 7, 'catalog/chevalet.jpg', 16, 1, 190.0000, 0, 9, '2016-12-07', 0.00000000, 1, 0.00000000, 0.00000000, 0.00000000, 1, 1, 1, 20, 1, 22, '2016-12-14 23:22:44', '2017-01-20 16:57:18'),
(56, '&quot;Musique&quot; 18*36', '', '', '', '', '', '', '', 1, 7, 'catalog/Musique.jpg', 0, 1, 700.0000, 0, 9, '2017-02-13', 0.00000000, 1, 18.00000000, 36.00000000, 0.00000000, 1, 1, 1, 1, 1, 8, '2017-02-13 20:21:40', '2017-02-13 20:23:33'),
(57, 'Image &quot; Chute d''eau&quot; ', '', '', '', '', '', '', '', 1, 7, 'catalog/Vodopad.jpg', 0, 1, 200.0000, 0, 9, '2017-02-13', 0.00000000, 1, 0.00000000, 0.00000000, 0.00000000, 1, 1, 1, 1, 1, 0, '2017-02-13 20:59:08', '0000-00-00 00:00:00'),
(58, 'Image &quot;Alpes&quot; 18*36', '', '', '', '', '', '', '', 1, 7, 'catalog/Alpes.jpg', 0, 1, 800.0000, 0, 9, '2017-02-13', 0.00000000, 1, 18.00000000, 36.00000000, 0.00000000, 1, 1, 1, 1, 1, 0, '2017-02-13 21:04:23', '2017-02-13 21:05:01'),
(59, 'Image &quot;Meteores&quot; 18*36', '', '', '', '', '', '', '', 1, 7, 'catalog/Meteores.jpg', 0, 1, 800.0000, 0, 9, '2017-02-13', 0.00000000, 1, 16.00000000, 36.00000000, 0.00000000, 1, 1, 1, 1, 1, 0, '2017-02-13 21:09:26', '0000-00-00 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
