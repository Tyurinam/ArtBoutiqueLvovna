-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2+deb7u8
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Mar 21 Mars 2017 à 20:49
-- Version du serveur: 5.5.54
-- Version de PHP: 5.4.45-0+deb7u7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `e1596124`
--

-- --------------------------------------------------------

--
-- Structure de la table `oc_membres`
--

CREATE TABLE IF NOT EXISTS `oc_membres`(
  `membre_id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacturer_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `article` varchar(1000) NOT NULL,
  `style_id` int(11) NOT NULL,
  PRIMARY KEY (`membre_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Contenu de la table `ocbd_membre`
--

INSERT INTO `oc_membre` (`membre_id`, `manufacturer_id`, `customer_id`, `article`,`style_id`) VALUES

(01, 1, 3,'Marina MarinaMarinaMarinaMarinaMarinaMarina', 1),
(02, 2, 2,'Tom TomTomTomTomTomTomTomTomTomTomTomTomTom', 2),
(03, 3, 1,'Jesus JesusJesusJesusJesusJesusJesusJesusJesus', 3);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- --------------------------------------------------------

--
-- Structure de la table `oc_styles`
--

CREATE TABLE IF NOT EXISTS `oc_styles`(
  `style_id` int(11) NOT NULL AUTO_INCREMENT,
  `stylename` varchar(32) NOT NULL,
  PRIMARY KEY (`style_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Contenu de la table `oc_styles`
/*Abstrait 
 Figuratif
Marine
Contemporain
Traditionnel
Photographie*/

--

INSERT INTO `oc_styles` (`style_id`, `stylename`) VALUES

(01, 'Traditionnel'),
(02, 'Contemporain'),
(03, 'Abstrait'),
(04, 'Figuratif'),
(05, 'Marine'),
(06, 'Photographie');

-- --------------------------------------------------------

---- --------------------------------------------------------

--
-- Structure de la table `oc_sujets`
--

CREATE TABLE IF NOT EXISTS `oc_sujets`(
  `sujet_id` int(11) NOT NULL AUTO_INCREMENT,
  `sujetname` varchar(32) NOT NULL,
  PRIMARY KEY (`sujet_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Contenu de la table `oc_sujets`
--

INSERT INTO `oc_sujets` (`sujet_id`, `sujetname`) VALUES

(01, 'Abstrait'),
(02, 'Animaux'),
(03, 'Nature Morte'),
(04, 'Paysage'),
(05, 'Personnage');

-- Structure de la table `oc_techniques`
--

CREATE TABLE IF NOT EXISTS `oc_techniques`(
  `technique_id` int(11) NOT NULL AUTO_INCREMENT,
  `techniquename` varchar(32) NOT NULL,
  PRIMARY KEY (`technique_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Contenu de la table `oc_techniques`
--

INSERT INTO `oc_techniques` (`technique_id`, `techniquename`) VALUES

(01, 'Acrylique'),
(02, 'Huile'),
(03, 'Aquarelle'),
(04, 'Collage'),
(05, 'Mixte'),
(06, 'Photographie');

-- --------------------------------------------------------

--
-- Structure de la table `oc_formates`
--

CREATE TABLE IF NOT EXISTS `oc_formates`(
  `formate_id` int(11) NOT NULL AUTO_INCREMENT,
  `formatename` varchar(32) NOT NULL,
  PRIMARY KEY (`formate_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Contenu de la table `oc_formates`
--

INSERT INTO `oc_formates` (`formate_id`, `formatename`) VALUES

(01, ' 19 x 19 cm'),
(02, ' 25 x 25 cm'),
(03, '36 x 36 cm'),
(04, ' 50 x 50 cm'),
(05, ' 40 x 120 / 120 x 40 cm'),
(06, ' 80 x 80 cm');

---- --------------------------------------------------------

--
-- Structure de la table `oc_nouvelles`
--

CREATE TABLE IF NOT EXISTS `oc_nouvelles`(
  `nouvelle_id` int(11) NOT NULL AUTO_INCREMENT,
 `date_added` datetime NOT NULL,
  `text` varchar(1000) NOT NULL,
  `membre_id` int(11) NOT NULL,
  PRIMARY KEY (`nouvelle_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Contenu de la table `oc_sujets`
--

INSERT INTO `oc_nouvelles` (`nouvelle_id`,`date_added`, `text`,`membre_id`) VALUES

(01, '2017-02-14 21:34:05', 'Abstrait', 1),
(02, '2017-03-14 21:34:05', 'Personnage', 2);
-- --------------------------------------------------------

--
-- Structure de la table `oc_oeuvres` product_id
--

CREATE TABLE IF NOT EXISTS `oc_oeuvres` (
  `oeuvre_id` int(11) NOT NULL AUTO_INCREMENT,
   `product_id` int(11) NOT NULL
    `membre_id` int(11) NOT NULL,
    `formate_id` int(11) NOT NULL,
    `sujet_id`int(11) NOT NULL,
    `style_id` int(11) NOT NULL,
    `technique_id` int(11) NOT NULL,
  PRIMARY KEY (`oeuvre_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=60 ;

--
