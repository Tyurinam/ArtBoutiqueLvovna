<?php
// Heading
$_['heading_title']    = 'Suscribirse al Bolet&iacute;n';

// Text
$_['text_account']     = 'Cuenta';
$_['text_newsletter']  = 'Bolet&iacute;n';
$_['text_success']     = '&Eacute;xito: Su suscripci&oacute;n al bolet&iacute;n se ha actualizado con &eacute;xito!';

// Entry
$_['entry_newsletter'] = 'Subscribir';
