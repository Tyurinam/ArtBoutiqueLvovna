<?php
// Heading
$_['heading_title'] = 'Salir de su cuenta';

// Text
$_['text_message']  = '<p>Usted Ha solicitado salir de su cuenta. Ahora es seguro abandonar el ordenador. </p> <p> Su cesta de la compra ha sido guardado y el contenido del mismo ser&aacute; restaurado cuando vuelva a entrar en su cuenta. </p>';
$_['text_account']  = 'Cuenta';
$_['text_logout']   = 'Salir';