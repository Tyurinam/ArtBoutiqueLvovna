<?php
// Heading
$_['heading_title']   = 'Ha olvidado su contrase&ntilde;a?';

// Text
$_['text_account']    = 'Cuenta';
$_['text_forgotten']  = 'Olvid&oacute; su Contrase&ntilde;a';
$_['text_your_email'] = 'Su E-Mail';
$_['text_email']      = 'Introduzca la direcci&oacute;n de correo electr&oacute;nico asociada con su cuenta. Haga clic en enviar para que su contrase&ntilde;a  llegue a correo electr&oacute;nico.';
$_['text_success']    = '&Eacute;xito: Una nueva contrase&ntilde;a ha sido enviada a su direcci&oacute;n de correo electr&oacute;nico.';

// Entry
$_['entry_email']     = 'E-Mail';

// Error
$_['error_email']     = 'Advertencia: La direcci&oacute;n de correo electr&oacute;nico no se encuentra en nuestros registros, por favor, int&eacute;ntalo de nuevo!';