<?php
// Heading
$_['heading_title'] = 'Tres artistas';

// Text
$_['text_tax']      = 'Sin Iva:';