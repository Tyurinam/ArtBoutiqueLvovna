<?php
// Heading
$_['heading_title'] = 'Novedades';

// Text
$_['text_tax']      = 'Sin Iva:';