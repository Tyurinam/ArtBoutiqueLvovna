<?php
// Heading
$_['heading_title'] = 'Exposición';

// Text
$_['text_tax']      = 'Sin Iva:';