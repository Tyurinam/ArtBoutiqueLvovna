<?php
// Heading
$_['heading_title'] = 'Escoge Una Tienda';

// Text
$_['text_default']  = 'Por Defecto';
$_['text_store']    = 'Por favor, elija la tienda que desea visitar.';