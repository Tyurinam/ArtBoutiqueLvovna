<?php
// Heading
$_['heading_title'] = 'Ofertas';

// Text
$_['text_tax']      = 'Sin Iva:';