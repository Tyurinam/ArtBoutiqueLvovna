<?php
// Heading
$_['heading_title']    = 'Afiliado';

// Text
$_['text_register']    = 'Registro';
$_['text_login']       = 'Iniciar Sesi&oacute;n';
$_['text_logout']      = 'Salir';
$_['text_forgotten']   = 'Contrase&ntilde;a Olvidada';
$_['text_account']     = 'Mi Cuenta';
$_['text_edit']        = 'Editar Cuenta';
$_['text_password']    = 'Contrase&ntilde;a';
$_['text_payment']     = 'Opciones de Pago';
$_['text_tracking']    = 'Programa de Afiliados';
$_['text_transaction'] = 'Transaciones';
