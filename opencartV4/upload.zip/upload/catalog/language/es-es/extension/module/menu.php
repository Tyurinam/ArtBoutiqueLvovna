<?php
// Heading
$_['heading_title'] = 'MenuModule';

// Text
$_['text_tax']      = 'Sin Iva:';
//*********************************************************************************MenuModule Marina 
$_['text_menumodule_1'] = 'Exposición';
$_['text_menumodule_2'] = 'Tienda';
$_['text_menumodule_3'] = 'Artistas';
$_['text_menumodule_4'] = 'Noticias';
$_['text_menumodule_5'] = 'Videos';
$_['text_menumodule_6'] = 'Contactos';
//*********************************************************************************MenuModule Marina 