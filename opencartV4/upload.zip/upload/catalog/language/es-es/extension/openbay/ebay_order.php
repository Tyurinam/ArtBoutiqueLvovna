<?php
// Text
$_['text_total_shipping']		= 'Env&iacute;o';
$_['text_total_discount']		= 'Descuento';
$_['text_total_tax']			= 'Taxas';
$_['text_total_sub']			= 'Sub-total';
$_['text_total']				= 'Total';