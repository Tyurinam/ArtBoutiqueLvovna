<?php
// Text
$_['text_title']				= 'Transferencia Bancaria';
$_['text_instruction']			= 'Instrucciones para Transferencia Bancaria';
$_['text_description']			= 'Por favor transfiera el importe total a la siguiente cuenta bancaria.';
$_['text_payment']				= 'Su pedido no se enviar&aacute; hasta que recibamos el pago.';