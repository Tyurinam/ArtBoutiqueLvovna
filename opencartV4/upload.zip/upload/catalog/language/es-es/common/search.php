<?php
// Text
$_['text_search'] = 'Busca, en la web !';