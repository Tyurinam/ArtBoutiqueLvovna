<?php
// Text
$_['text_items']    = '%s art&iacute;culo(s) - %s';
$_['text_empty']    = 'Tu carro esta vac&iacute;o!';
$_['text_cart']     = 'Ver Carrito';
$_['text_checkout'] = 'Caja';
$_['text_recurring']  = 'Perfil de pago';