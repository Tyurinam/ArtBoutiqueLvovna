<?php
// Text
$_['text_information']  = 'Informaci&oacute;n';
$_['text_service']      = 'Servicio al Cliente';
$_['text_extra']        = 'Extras';
$_['text_contact']      = 'Contacte';
$_['text_return']       = 'Devoluciones';
$_['text_sitemap']      = 'Mapa';
$_['text_manufacturer'] = 'Marca';
$_['text_voucher']      = 'Vales Regalo';
$_['text_affiliate']    = 'Afiliados';
$_['text_special']      = 'Ofertas';
$_['text_account']      = 'Mi Cuenta';
$_['text_order']        = 'Historial de Pedidos';
$_['text_wishlist']     = 'Lista de Deseos';
$_['text_newsletter']   = 'Bolet&iacute;n Noticias';
$_['text_powered']      = 'Creado con <a href="https://wuam.es">Opencart</a><br /> %s &copy; %s';