<?php
// Heading
$_['heading_title']        = 'Su pedido ha sido realizado!';

// Text
$_['text_basket']          = 'Carro de compras';
$_['text_checkout']        = 'Caja';
$_['text_success']         = 'Genial';
$_['text_customer']        = '<p>Su pedido ha sido procesado con &eacute;xito!</p><p>Usted puede ver su historial de pedidos o ir a <a href="%s">mi cuenta</a> p&aacute;gina y haciendo clic en <a href="%s">historial</a>.</p><p>Si su compra tiene una descarga asociada, se puede ir a la cuenta <a href="%s">descargas</a> para que pueda bajarlas y disfrutar de ellas.</p><p>Por favor, dirija cualquier pregunta que tenga al <a href="%s">propietario de la tienda</a>.</p><p>Gracias por hacer compras con nosotros!</p>';
$_['text_guest']           = '<p>Su pedido ha sido procesado con &eacute;xito!</p><p>Por favor, dirija cualquier pregunta que tenga al <a href="%s">propietario de la tienda</a>.</p><p>Gracias por hacer compras con nosotros!</p>';