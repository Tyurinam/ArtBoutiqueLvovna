<?php
// Heading
$_['heading_title']        = 'Mi cuenta de afiliado';

// Text
$_['text_account']         = 'Cuenta';
$_['text_my_account']      = 'Mi cuenta de afiliado';
$_['text_my_tracking']     = 'Mi Informaci&oacute;n de rastreo';
$_['text_my_transactions'] = 'Mis Transacciones';
$_['text_edit']            = 'Editar informaci&oacute;n de la cuenta';
$_['text_password']        = 'Cambiar su contrase&ntilde;a';
$_['text_payment']         = 'Cambiar preferencias de pago';
$_['text_tracking']        = 'C&oacute;digo de seguimiento personalizado del afiliado';
$_['text_transaction']     = 'Ver historial de transacciones';