<?php
// Heading
$_['heading_title'] = 'Salir de la cuenta de afiliados';

// Text
$_['text_message']  = '<p>Ha solicitado salir de su cuenta de socios.</p>';
$_['text_account']  = 'Cuenta';
$_['text_logout']   = 'Salir';