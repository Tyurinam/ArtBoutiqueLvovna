<?php
// Heading
$_['heading_title']  = 'Cambiar contrase&ntilde;a';

// Text
$_['text_account']   = 'Cuenta';
$_['text_password']  = 'Contrase&ntilde;a';
$_['text_success']   = '&Eacute;xito: Su contrase&ntilde;a se ha actualizado correctamente.';

// Entry
$_['entry_password'] = 'Contrase&ntilde;';
$_['entry_confirm']  = 'Confirmar contrase&ntilde;a';

// Error
$_['error_password'] = 'La contrase&ntilde;a debe tener entre 4 y 20 caracteres!';
$_['error_confirm']  = 'Confirmaci&oacute;n de la contrase&ntilde;a no coincide con la contrase&ntilde;a!';