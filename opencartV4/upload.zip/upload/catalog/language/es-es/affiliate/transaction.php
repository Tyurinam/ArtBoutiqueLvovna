<?php
// Heading
$_['heading_title']      = 'Transacciones';

// Column
$_['column_date_added']  = 'Fecha';
$_['column_description'] = 'Descrici&oacute;n';
$_['column_amount']      = 'Importe (%s)';

// Text
$_['text_account']       = 'Cuenta';
$_['text_transaction']   = 'Transacci&oacute;nes';
$_['text_balance']       = 'Su saldo actual es:';
$_['text_empty']         = 'Usted no tiene ninguna transacci&oacute;n!';