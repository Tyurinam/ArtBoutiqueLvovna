<?php
// Text
$_['text_success']     = 'El &eacute;xito: sus puntos de recompensa de descuento se ha aplicado!';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para acceder a la API!';
$_['error_reward']     = 'Advertencia: Por favor, introduzca la cantidad de puntos de recompensa para utilizar!';
$_['error_points']     = 'Advertencia: Usted  tiene puntos de recompensa %s!';
$_['error_maximum']    = 'Advertencia: El n&uacute;mero m&aacute;ximo de puntos que se puede aplicar es %s!';