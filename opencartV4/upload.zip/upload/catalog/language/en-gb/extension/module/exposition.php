<?php
// Heading
$_['heading_title'] = 'Exposition';

// Text
$_['text_tax']      = 'Ex Tax:';