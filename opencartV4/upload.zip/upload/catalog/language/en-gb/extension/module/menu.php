<?php
// Heading
$_['heading_title'] = 'MenuModule';

// Text
$_['text_tax']      = 'Ex Tax:';
//*********************************************************************************MenuModule Marina 
$_['text_menumodule_1'] = 'Exposition';
$_['text_menumodule_2'] = 'Shop';
$_['text_menumodule_3'] = 'Artists';
$_['text_menumodule_4'] = 'News';
$_['text_menumodule_5'] = 'Video';
$_['text_menumodule_6'] = 'Contacts';
//*********************************************************************************menumodule Marina 