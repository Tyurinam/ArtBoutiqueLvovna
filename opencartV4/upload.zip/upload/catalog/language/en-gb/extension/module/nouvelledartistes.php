TextNouvelle<!--
    * Projet : PROJET WEB 2
               Artboutique.
	* Organisation : Collège de Maisonneuve
    * @author Jesus MARTINEZ REYNOSO, Marina Tyurina
    * @version 2017-04-14
-->

<!--

	* Description : préparer les variables globales
	description en anglais
	pour tous les fichiers nouvellesdartistes

-->

<?php
// Heading 
$_['heading_title']		= 'Nouvelles des artistes';

// Text
$_['text_contact']		= 'Contact us';
$_['text_sitemap']		= 'Site Map'; 


/*$_['LidProduit']   	= 'id Product';
$_['LDescription']  = 'Description';
$_['LPrixDepart']   = 'Starting Price';*/
$_['LDateAdd'] 		= 'Date Add';
$_['TextNouvelle']  = 'Proposed TextNouvelle';
$_['LidNouvelle']   	= 'id Nouvelle';
$_['LidMembre']   	= 'id Membre';

