<?php
// Heading
$_['heading_title'] = 'Three artists';

// Text
$_['text_tax']      = 'Ex Tax:';