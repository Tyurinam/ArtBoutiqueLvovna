<?php
// Heading 
$_['heading_title']		= 'Selections Oeuvres';

// Text
$_['text_contact']		= 'Contact us';
$_['text_sitemap']		= 'Site Map';
?>