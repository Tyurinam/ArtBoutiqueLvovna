<?php
// Heading 
$_['heading_title']		= 'Selection Artistes';

// Text
$_['text_contact']		= 'Contact us';
$_['text_sitemap']		= 'Site Map';
?>