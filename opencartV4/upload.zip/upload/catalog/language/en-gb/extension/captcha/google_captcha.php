<?php
// Text
$_['text_captcha'] = 'Captcha';

// Entry
$_['entry_captcha'] = 'Please complete the captcha validation below';

// Error
$_['error_captcha'] = 'Verification is not correct!';
