<?php
// Heading
$_['heading_title'] = 'Our  Artistes';

// Text
$_['text_news'] 			= 'Artistes';
$_['text_membre_id'] 		= 'Id Membre';
$_['text_manufacturer_id'] 	= 'Id Manufacturer';
$_['text_view'] 			= 'View';
$_['text_error'] 			= 'The page you are looking for cannot be found.';
$_['text_separator'] 		= '&gt;'; 