<?php
// Controller � Fichier du contr�leur.
// Artboutique � Son r�pertoire.
// Artiste � nom du fichier artiste.php
// Tous les contr�leur ont une fonction index()
class ControllerArtboutiqueArtistes extends Controller {

	public function index() {
		$this->language->load('artboutique/artistes'); // Appel au fichier langage
		$this->load->model('catalog/artistes'); // Appel au mod�le
		$this->document->setTitle($this->language->get('heading_title')); 
		// Set the title of your web page.
		
		$data['breadcrumbs'] = array(); // Fil d�Ariane
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home'), 'separator' => false
			);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('artboutique/artistes'),
			'separator' => $this->language->get('text_separator')
			);
		// Texte pris dans le fichier du langage
		$data['heading_title'] 			= $this->language->get('heading_title');
		$data['text_membre_id'] 		= $this->language->get('text_membre_id');
		$data['text_manufacturer_id'] 	= $this->language->get('text_manufacturer_id');
		$data['text_view'] 				= $this->language->get('text_view');

		// Appel de la fonction getAllartistes du mod�le
		if(isset($_POST["stylesel"])) {
			$parametres=$_POST["stylesel"];
		} else {
			$parametres = "all";
			}
		$all_artistes = $this->model_catalog_artistes->getAllArtistes($parametres);
		//var_dump($all_artistes);
		$data['all_artistes'] = array();
		
		foreach ($all_artistes as $artistes) {
			$data['all_artistes'][] = array (
				'membre_id' 			=> $artistes['membre_id'],
				'name' 					=> $artistes['name'],
				'image' 				=> $artistes['image'],
				'manufacturer_id' 		=> $artistes['manufacturer_id'],
				'view' => $this->url->link('artboutique/artistes/artiste', 'membre_id=' . $artistes['membre_id'])
				);
		}
		
		//var_dump($data);
		
		// Requis. Les fichiers contenus dans la page.
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
 
		$this->response->setOutput($this->load->view('artboutique/artistes_list ', $data));
	}
	public function artiste() {
		$this->load->model('catalog/artistes');
		$this->language->load('artboutique/artistes');

		if (isset($this->request->get['membre_id']) && !empty($this->request->get['membre_id'])) {
			$membre_id = $this->request->get['membre_id'];
		} else {
			$membre_id = 0;
			}

		$artiste = $this->model_catalog_artistes->getArtiste($membre_id);

		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home'),
			'separator' => false
			); 
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('artboutique/artistes'),
			'separator' => $this->language->get('text_separator')
			);

		if ($artiste) {
			$data['breadcrumbs'][] = array(
				'text' => $artiste['name'],
				'href' => $this->url->link('artboutique/artistes/artiste', 'membre_id=' . $membre_id),
				'separator' => $this->language->get('text_separator')
				);

			$this->document->setTitle($artiste['name']);

			$data['heading_title'] 	= $artiste['name'];
			$data['image'] 			= $artiste['image'];

			$data['column_left'] = $this->load->controller('common/column_left');
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['content_top'] = $this->load->controller('common/content_top');
			$data['content_bottom'] = $this->load->controller('common/content_bottom');
			$data['footer'] = $this->load->controller('common/footer');
			$data['header'] = $this->load->controller('common/header');
			$this->response->setOutput($this->load->view('artboutique/artiste', $data));
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_error'),
				'href' => $this->url->link('artboutique/artistes', 'membre_id=' . $membre_id),
				'separator' => $this->language->get('text_separator')
			);
		}
	}
	
}
?>