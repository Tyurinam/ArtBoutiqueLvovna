<!--
	* 
    * Projet : PROJET WEB 2
               Artboutique.
	* Organisation : Collège de Maisonneuve
    * @author Jesus MARTINEZ REYNOSO, Marina Tyurina
    * @version 2017-04-14
-->

<!--

	* index (Controller)
	* @public
	* Description : Controller gère le module de Côté client ,
	 prepere le tableu data pour view


-->

<?php
class ControllerExtensionModuleEnchercles extends Controller {
	public function index() {
		$this->load->language('extension/module/enchercles');

		$data['heading_title'] = $this->language->get('heading_title');
		
		$data['LidProduit']   = $this->language->get('LidProduit'); 
		$data['LDescription'] = $this->language->get('LDescription');
		$data['LPrixDepart']  = $this->language->get('LPrixDepart');
		$data['LDateFin']     = $this->language->get('LDateFin');
		$data['LPrixPropose'] = $this->language->get('LPrixPropose');

		$data['text_contact'] = $this->language->get('text_contact');
		$data['text_sitemap'] = $this->language->get('text_sitemap');
		
		$data['clientConnecte'] = $this->customer->isLogged();
		
		$utilisateur = $this->customer->isLogged();
		
		

		if (!isset($this->request->post['prixMin']) ) 	
			$prixMin = 0;
		else 
			$prixMin = $this->request->post['prixMin'];
			
		if (!isset($this->request->post['prixMax']) ) 	
			$prixMax = 10000;
		else 
			$prixMax = $this->request->post['prixMax'];
			
			//echo( "Prix Min/Max :" . $prixMin.'/'.$prixMax); 

		
		
		
		
		$this->load->model('catalog/product');

		$data['enchercles'] = array();

		$filter_data = array(
			'sort'  => 'pd.name',
			'order' => 'ASC'  /*,
			'start' => 0,
			'limit' => 3 */
		);

		
		/**
		$results = $this->model_catalog_product->getProductSpecials($filter_data);
		
		if ($results) {
			foreach ($results as $result) {
				if ($result['special'] >= $prixMin && $result['special'] <= $prixMax){
					$data['enchercles'][] = array(
					'product_id'  => $result['product_id'],
					'name'        => $result['name'],
					'price'     => $result['price'],
					'special'     => $result['special']);
				}
			}
		}
		
		**/
		 
 
		
		/***********   Agregado  *****/
		
		$this->load->model('catalog/enchercles'); 
		$results = $this->model_catalog_enchercles->ObtenirLesEncheres($filter_data);				
		
		if ($results) {
			foreach ($results as $result) { 
				/* if ($result['special'] >= $prixMin && $result['special'] <= $prixMax){ */
				if ( date("Y-m-d H:i:s") <= $result['DateFin']) {
					$data['enchercles'][] = array(
					'idProduit'   => $result['idProduit'],
					'PrixDepart'  => $result['PrixDepart'],
					'Description'  => $result['name'],
					'DateFin'     => $result['DateFin'],
					'PrixPropose' => $result['PrixPropose'],
					'vainqueur'   => $result['vainqueur'],
					);
				}	
				/* } */
			}
		}		
		
		/****   Fin Agregado  *****************/
		
		// Action à exécuter quand on envoie le formulaire
		//$data['action'] = $this->url->link('common/home', '', true);
		
		
		$data['action'] = $_SERVER['PHP_SELF'];
         
		 
     /***  +++++++++++++++++++++++++++++++++++++++  **/
      
	   
 
         if(  (isset($_GET["PrixPropose"])) and 
		      (!empty($_GET["PrixPropose"])) )
	    {
		    	
             $PrixPropose=$_GET["PrixPropose"];
             $idProduitEnchere= $_GET["idProduitEnchere"];			
         
         
            $this->load->model('catalog/enchercles');

            echo "Enrando Aqui encore".$PrixPropose."-".$idProduitEnchere;
           
			
            if(isset($utilisateur) and $utilisateur!=""){
			
				$this->model_catalog_enchercles->AjouterHistoriqueEnchere($idProduitEnchere,$PrixPropose,$utilisateur);    
		   
            }
 
        } 
		
		
	
     /****+++++++++++++++++++++++++++++++++++++++++ ***/
		 
		 
		 

		
		
		
		//print_r($data); die();

		$data['contact'] = $this->url->link('enchercles/contact');
		$data['sitemap'] = $this->url->link('enchercles/sitemap');

		return $this->load->view('extension/module/enchercles', $data);
	}
}