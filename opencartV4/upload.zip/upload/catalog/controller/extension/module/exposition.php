<?php
class ControllerExtensionModuleExposition extends Controller {
   
	public function index($setting) {
		$this->load->language('extension/module/exposition');
        $this->load->model('catalog/artistes'); // Appel au modèle
         $this->load->model('catalog/oeuvres'); // Appel au modèle
        
		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_tax'] = $this->language->get('text_tax');

		$data['button_cart'] = $this->language->get('button_cart');
		$data['button_wishlist'] = $this->language->get('button_wishlist');
		$data['button_compare'] = $this->language->get('button_compare');
        // Appel de la fonction getAllartistes du modèle
		if(isset($_POST["stylesel"])) {
			$parametresstyle=$_POST["stylesel"];
        } else {
			$parametresstyle="all";
        }
        if(isset($_POST["formatesel"])) {
			$parametresformate=$_POST["formatesel"];
        } else {
			$parametresformate="all";
        }
        if(isset($_POST["techniquesel"])) {
			$parametrestechnique=$_POST["techniquesel"];
        } else {
			$parametrestechnique="all";
        }
       //var_dump($_POST);
        //$parametres = "all";
		$all_artistes = $this->model_catalog_artistes->getAllArtistes($parametresstyle);
		//var_dump($all_artistes);
		$data['all_artistes'] = array();
		
		
        foreach ($all_artistes as $artistes){
        
			$data['all_artistes'][] = array (
				'membre_id' 			=> $artistes['membre_id'],
				'name' 					=> $artistes['name'],
				'image' 				=> $artistes['image'],
				'manufacturer_id' 		=> $artistes['manufacturer_id']
				//'view' => $this->url->link('artboutique/artistes/artiste', 'membre_id=' . $artistes['membre_id'])
				);
		}
        
        /*Isabel*/
       $this->load->model('catalog/selectionoeuvres');

		$data['selectionstyles'] 		= array();
		$data['selectionformates'] 		= array();
		$data['selectiontechniques'] 	= array();

		$results = $this->model_catalog_selectionoeuvres->getStyles();
		
		if ($results) {
			foreach ($results as $result) {
				
					$data['selectionstyles'][] = array(
					'style_id'  	=> $result['style_id'],
					'stylename'     => $result['stylename']);
				
			}
		}
		
		$results = $this->model_catalog_selectionoeuvres->getFormates();
		
		if ($results) {
			foreach ($results as $result) {
				
					$data['selectionformates'][] = array(
					'formate_id'  	=> $result['formate_id'],
					'formatename'   => $result['formatename']);
				
			}
		}
		
		$results = $this->model_catalog_selectionoeuvres->getTechniques();
		
		if ($results) {
			foreach ($results as $result) {
				
					$data['selectiontechniques'][] = array(
					'technique_id'  	=> $result['technique_id'],
					'techniquename'     => $result['techniquename']);
				
			}
		}
		
		
        /*Isabel*/

		$this->load->model('catalog/product');

		$this->load->model('tool/image');

		$data['products'] = array();

		$filter_data = array(
			//'sort'  => 'p.date_added',
            'sort'  => 'p.manufacturer_id',
			'order' => 'DESC',
			'start' => 0,
			'limit' => $setting['limit']
		);


		$results = $this->model_catalog_product->getProducts($filter_data);

		if ($results) {
			foreach ($results as $result) {
                
				if ($result['image']) {
					$image = $this->model_tool_image->resize($result['image'], $setting['width'], $setting['height']);
				} else {
					$image = $this->model_tool_image->resize('placeholder.png', $setting['width'], $setting['height']);
				}

				if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
					$price = $this->currency->format($this->tax->calculate($result['price'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$price = false;
				}

				if ((float)$result['special']) {
					$special = $this->currency->format($this->tax->calculate($result['special'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$special = false;
				}

				if ($this->config->get('config_tax')) {
					$tax = $this->currency->format((float)$result['special'] ? $result['special'] : $result['price'], $this->session->data['currency']);
				} else {
					$tax = false;
				}

				if ($this->config->get('config_review_status')) {
					$rating = $result['rating'];
				} else {
					$rating = false;
				}
                
               /* if ($this->config->get('manufacturer_id')) {
                $manufacturer_id=$result['manufacturer_id'];
                }*/
                 if ($this->config->get('manufacturer')) {
                $manufacturer=$result['manufacturer'];
                }
                
                /* oeuvre*/
   // $resultsoeuvre = $this->model_catalog_oeuvres->getOeuvre($result['product_id'],$data['selectionstyles'],$data['selectionformates'],$data['selectiontechniques']);
            $resultsoeuvre = $this->model_catalog_oeuvres->getOeuvre($result['product_id'], $parametresstyle, $parametresformate, $parametrestechnique);
                if (isset($resultsoeuvre)) {
               
               
                
				$data['products'][] = array(
					'product_id'  => $result['product_id'],
					'thumb'       => $image,
					'name'        => $result['name'],
					'description' => utf8_substr(strip_tags(html_entity_decode($result['description'], ENT_QUOTES, 'UTF-8')), 0, $this->config->get($this->config->get('config_theme') . '_product_description_length')) . '..',
					'price'       => $price,
					'special'     => $special,
					'tax'         => $tax,
					'rating'      => $rating,
					'href'        => $this->url->link('product/product', 'product_id=' . $result['product_id']),
                    'manufacturer'      => $result['manufacturer']
            //'manufacturer_id'      => $result['manufacturer_id']
                    
				);
                     }
                
			}
         //var_dump($data);
			return $this->load->view('extension/module/exposition', $data);
        
		}

	}
}

