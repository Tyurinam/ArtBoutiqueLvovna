<!--
	* 
    * Projet : PROJET WEB 2
               Artboutique.
	* Organisation : Collège de Maisonneuve
    * @author Jesus MARTINEZ REYNOSO, Marina Tyurina
    * @version 2017-04-14
-->

<!--

	* index (Controller)
	* @public
	* Description : Controller gère le module de Côté client ,
	 prepere le tableu data pour view


-->

<?php
class ControllerExtensionModuleNouvelledartistes extends Controller {
	public function index() {
		$this->load->language('extension/module/nouvelledartistes');

		$data['heading_title'] = $this->language->get('heading_title');
		
		$data['LDateAdd']     = $this->language->get('LDateAdd');
		$data['TextNouvelle'] = $this->language->get('TextNouvelle');

		/*$data['text_contact'] = $this->language->get('text_contact');
		$data['text_sitemap'] = $this->language->get('text_sitemap');*/
		
		$data['clientConnecte'] = $this->customer->isLogged();
		
		$utilisateur = $this->customer->isLogged();
		
		

        
		
       /* $prixMin = 0;
		else 
			$prixMin = $this->request->post['prixMin'];
			
		if (!isset($this->request->post['prixMax']) ) 	
			$prixMax = 10000;
		else 
			$prixMax = $this->request->post['prixMax'];
			
			//echo( "Prix Min/Max :" . $prixMin.'/'.$prixMax); 

		
		
		*/
		
		

		
	
		
		$this->load->model('catalog/nouvelledartistes'); 
		$results = $this->model_catalog_nouvelledartistes->ObtenirLesNouvelledartistes();				
		//var_dump($results);
		if ($results) {
			foreach ($results as $result) { 
				/* if ($result['special'] >= $prixMin && $result['special'] <= $prixMax){ */
			 
					$data['nouvelledartistes'][] = array(
					/*'idProduit'   => $result['idProduit'],
					'PrixDepart'  => $result['PrixDepart'],
					'Description'  => $result['name'],*/
					'LDateAdd'     => $result['date_added'],
					'TextNouvelle' => $result['meta_text']
				/*'vainqueur'   => $result['vainqueur']*/
					);
					
				/* } */
                
			}
			
			//var_dump($data['nouvelledartistes']);
			
			
		}		
		
		/****   Fin Agregado  *****************/
		
		// Action à exécuter quand on envoie le formulaire
		//$data['action'] = $this->url->link('common/home', '', true);
		
		
		$data['action'] = $_SERVER['PHP_SELF'];
         
		 
     /***  +++++++++++++++++++++++++++++++++++++++  **/
      
	   
 /*
         if(  (isset($_GET["TextNouvelle"])) and 
		      (!empty($_GET["TextNouvelle"])) )
	    {
		    	
             $TextNouvelle=$_GET["TextNouvelle"];
             $idProduitEnchere= $_GET["idProduitEnchere"];			
         
         
            $this->load->model('catalog/nouvelledartistes');

            echo "Enrando Aqui encore".$TextNouvelle."-".$idProduitEnchere;
           
			
            if(isset($utilisateur) and $utilisateur!=""){
			
				$this->model_catalog_nouvelledartistes->AjouterHistoriqueEnchere($idProduitEnchere,$TextNouvelle,$utilisateur);    
		   
            }
 
        } */
		
		
	
     /****+++++++++++++++++++++++++++++++++++++++++ ***/
		 
		 
		 

		
		
		
		//print_r($data); die();

		$data['contact'] = $this->url->link('nouvelledartistes/contact');
		$data['sitemap'] = $this->url->link('nouvelledartistes/sitemap');

		return $this->load->view('extension/module/nouvelledartistes', $data);
	}
}