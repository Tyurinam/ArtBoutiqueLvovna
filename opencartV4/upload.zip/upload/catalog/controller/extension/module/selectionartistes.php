<?php
class ControllerExtensionModuleSelectionartistes extends Controller {
	public function index() {
		$this->load->language('extension/module/selectionartistes');

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_contact'] = $this->language->get('text_contact');
		$data['text_sitemap'] = $this->language->get('text_sitemap');
			
		$this->load->model('catalog/selectionoeuvres');

		$data['selectionstyles'] 		= array();

		$results = $this->model_catalog_selectionoeuvres->getStyles();
		
		if ($results) {
			foreach ($results as $result) {
				
					$data['selectionstyles'][] = array(
					'style_id'  	=> $result['style_id'],
					'stylename'     => $result['stylename']);
				
			}
		}
		
		// Action à exécuter quand on envoie le formulaire
		$data['action'] = $this->url->link('artboutique/artistes', '', true);
		
		//print_r($data); die();

		$data['contact'] = $this->url->link('selectionartistes/contact');
		$data['sitemap'] = $this->url->link('selectionartistes/sitemap');

		return $this->load->view('extension/module/selectionartistes', $data);
	}
}