<?php
class ControllerExtensionModuleSelectionoeuvres extends Controller {
	public function index() {
		$this->load->language('extension/module/selectionoeuvres');

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_contact'] = $this->language->get('text_contact');
		$data['text_sitemap'] = $this->language->get('text_sitemap');

				
		$this->load->model('catalog/selectionoeuvres');

		$data['selectionstyles'] 		= array();
		$data['selectionformates'] 		= array();
		$data['selectiontechniques'] 	= array();

		$results = $this->model_catalog_selectionoeuvres->getStyles();
		
		if ($results) {
			foreach ($results as $result) {
				
					$data['selectionstyles'][] = array(
					'style_id'  	=> $result['style_id'],
					'stylename'     => $result['stylename']);
				
			}
		}
		
		$results = $this->model_catalog_selectionoeuvres->getFormates();
		
		if ($results) {
			foreach ($results as $result) {
				
					$data['selectionformates'][] = array(
					'formate_id'  	=> $result['formate_id'],
					'formatename'   => $result['formatename']);
				
			}
		}
		
		$results = $this->model_catalog_selectionoeuvres->getTechniques();
		
		if ($results) {
			foreach ($results as $result) {
				
					$data['selectiontechniques'][] = array(
					'technique_id'  	=> $result['technique_id'],
					'techniquename'     => $result['techniquename']);
				
			}
		}
		 
		
		
		// Action à exécuter quand on envoie le formulaire
		$data['action'] = $this->url->link('artboutique/exposition', '', true);
		
		//print_r($data); die();

		$data['contact'] = $this->url->link('selectionoeuvres/contact');
		$data['sitemap'] = $this->url->link('selectionoeuvres/sitemap');

		return $this->load->view('extension/module/selectionoeuvres', $data);
	}
}