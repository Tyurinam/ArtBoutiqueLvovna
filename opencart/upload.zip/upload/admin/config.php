<?php
// HTTP
define('HTTP_SERVER', 'http://e1695162.webdev.cmaisonneuve.qc.ca/projetweb2/upload/admin/');
define('HTTP_CATALOG', 'http://e1695162.webdev.cmaisonneuve.qc.ca/projetweb2/upload/');

// HTTPS
define('HTTPS_SERVER', 'http://e1695162.webdev.cmaisonneuve.qc.ca/projetweb2/upload/admin/');
define('HTTPS_CATALOG', 'http://e1695162.webdev.cmaisonneuve.qc.ca/projetweb2/upload/');

// DIR
define('DIR_APPLICATION', '/var/www/vhosts/e1695162/www/projetweb2/upload/admin/');
define('DIR_SYSTEM', '/var/www/vhosts/e1695162/www/projetweb2/upload/system/');
define('DIR_IMAGE', '/var/www/vhosts/e1695162/www/projetweb2/upload/image/');
define('DIR_LANGUAGE', '/var/www/vhosts/e1695162/www/projetweb2/upload/admin/language/');
define('DIR_TEMPLATE', '/var/www/vhosts/e1695162/www/projetweb2/upload/admin/view/template/');
define('DIR_CONFIG', '/var/www/vhosts/e1695162/www/projetweb2/upload/system/config/');
define('DIR_CACHE', '/var/www/vhosts/e1695162/www/projetweb2/upload/system/storage/cache/');
define('DIR_DOWNLOAD', '/var/www/vhosts/e1695162/www/projetweb2/upload/system/storage/download/');
define('DIR_LOGS', '/var/www/vhosts/e1695162/www/projetweb2/upload/system/storage/logs/');
define('DIR_MODIFICATION', '/var/www/vhosts/e1695162/www/projetweb2/upload/system/storage/modification/');
define('DIR_UPLOAD', '/var/www/vhosts/e1695162/www/projetweb2/upload/system/storage/upload/');
define('DIR_CATALOG', '/var/www/vhosts/e1695162/www/projetweb2/upload/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'e1695162');
define('DB_PASSWORD', '690403');
define('DB_DATABASE', 'e1695162');
define('DB_PORT', '3306');
define('DB_PREFIX', 'ocpw2_');
